![Banner](assets/banner2.png)

# Crea tu primera página.

**Tema:** Desarrollo de plantilla de un blog

**Modalidad:** Individual

**Objetivo:** Desarrollar un sitio web que contenga una página principal y tres artículos.

# Descripción

Desarrollarás paso a paso un blog. 

En la construcción del sitio, seguiremos este orden:

- [ALCANCE 1 - Revisarás instalaciones y requerimientos técnicos](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-1---revisar%C3%A1s-instalaciones-y-requerimientos-t%C3%A9cnicos)
- [ALCANCE 2 - Construirás la estructura de carpetas y archivos](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-2---construir%C3%A1s-la-estructura-de-carpetas-y-archivos)
- [ALCANCE 3 - Conectarás archivos con `index.html`](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-3---conectar%C3%A1s-archivos-con-indexhtml)
- [ALCANCE 4 - Harás las etiquetas HTML de `<header>`](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-4---har%C3%A1s-las-etiquetas-html-de-header)
- [ALCANCE 5 - Harás las etiquetas HTML de `<main>`](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-5---har%C3%A1s-las-etiquetas-html-de-main)
- [ALCANCE 6 - Obtendrás tres artículos](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-6---obtendr%C3%A1s-tres-art%C3%ADculos)
- [ALCANCE 7 - Insertarás estilos dentro las etiquetas](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-7---insertar%C3%A1s-estilos-dentro-las-etiquetas)
- [ALCANCE 8 - Cambiarás el contenido por el que tú gustes](https://github.com/UDDBootcamp/PPV-Landing-Blog#alcance-8---cambiar%C3%A1s-el-contenido-por-el-que-t%C3%BA-gustes)

Puedes ver el demo aquí mismo: [LINK A DEMO](https://dazzling-edison-4ea7d6.netlify.app/)

![](assets/demo.png)

# Entregables

Al terminar tu actividad guiada:

- Graba un `LOOM` presentando tu proyecto. Puedes ver el tutorial encontrado en la plataforma de Teams.
- Sube el link de `LOOM` a la plataforma como "assignment" para su revisión y aprobación.

## ALCANCE 1 - Revisarás instalaciones y requerimientos técnicos

Antes de comenzar, te pediré que revises que tengas instalado Visual Studio Code. 

Esto ya lo hemos hecho anteriormente en otras actividades, sólo es confirmando que lo tienes.

> Es posible que quieras trabajar con otro editor. Está bien, pero como recomendación, en esta ocasión trabaja con Visual Studio Code, para que puedas seguir mejor la actividad.

Una vez instalado Visual Studio Code, encuentra en la barra lateral izquierda este ícono: 

![](./assets/1.png)

Dentro, buscarás la extensión de "LIVE SERVER" y la instalarás.

![](./assets/2.png)

Con esto, empecemos a construir la aplicación.

## ALCANCE 2 - Construirás la estructura de carpetas y archivos

Observa a continuación este Wireframe.

![](./assets/3.png)

Identifica las diferentes secciones y las etiquetas que serán indispensables en su construcción:

- **header.** Incluirá una foto tuya del lado izquierdo, con el nombre de tu blog, y del lado derecho un botón que contendrá un mensaje "ENVÍAME UN CORREO".
- **main.** La zona principal del blog.
    - **h1.** Incluirá el título del blog.
    - **p.** Incluirá la descripción del blog.
- **section** En él, se insertará la zona de artículos.
    - **Article** Representa un artículo. Cada uno de ellos contendrá:
        - **img.** La imagen del artículo. Puede ser en un formato .jpg, .jpeg, .png, etc.
        - **span.** La categoría del artículo.
        - **h2.** El título del artículo.
        - **p.** La descripción del artículo
        - **time.** La fecha del artículo

Con esto claro, construye la estructura de archivos y carpetas. 

Sitúate en tu Visual Studio Code, en la barra `"EXPLORER"` y empieza a crear los archivos y carpetas.

Puedes dar click en este ícono para ver la columna de archivos y carpetas.

![](./assets/4.png)

Perfecto. Te debe quedar de esta manera:

```
|- /css
|   |- styles.css
|- /img
    |- [tus-imágenes].jpg
    |- ...
|- index.html
|- estilos.css

```

Con respecto a las imágenes, vas a descargar este [.zip](https://github.com/UDDBootcamp/PPV-Landing-Blog/blob/main/assets/img.zip). Aquí se encuentran todas y deberás moverlas a la carpeta `/img`.

## ALCANCE 3 - Conectarás archivos con `index.html`

A continuación, nos situaremos en nuestro archivo `index.html` y empezaremos trabajando las etiquetas `head`. 

Inserta el siguiente código y vamos analizándolo:

```html

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="estilos.css">
    <title>Blog Personal</title>
</head>

<body>
    <p>hola mundo</p>
</body>

</html>

```

- `<!DOCTYPE html>`. Establecerás que se usará HTML 5, el último estándar para ejecutar todas las etiquetas disponibles y actuales.
- `<html>`. La etiqueta HTML para indicar que harás un documento HTML.
- `<head>`. Permitirá incluir tus metadatos y tus vínculos a archivos externos.
    - `<meta>`. Una etiqueta de metadatos, es decir, información general de la página para ser leída por otros servicios, como el navegador.  
    - `<link>`. Una etiqueta para conectar un archivo externo. Puede ser un archivo CSS o JS.
        - `rel`. Especifica el tipo de archivo que estamos trabajando.
        - `href`. La ruta hacia el archivo CSS. Más adelante explicaremos sobre el tema de rutas relativas.
    - `<title>`. Una etiqueta que señala el título de la página. Cada página siempre tiene una.

- `<body>`. Se refiere a todo el contenido que habrá en el sitio web. Aquí es donde soltaremos todas las etiquetas HTML y para construirlo.
    - `<p>`. Es una etiqueta de párrafo. Verás que tiene el contenido "hola mundo".


A partir de este momento, da click derecho a tu `ìndex.html` en tu barra de archivos y da click a **"Open with Live Server"**.

![](./assets/5.png)

Te saldrá la imagen "hola mundo" en el navegador que tengas por defecto.

![](./assets/6.png)

El alcance está terminado, pasemos al siguiente.

## ALCANCE 4 - Harás las etiquetas HTML de `<header>`

Para empezar, deberemos construir la estructura del sitio web.

> Es posible que muchas etiquetas sean incomprensibles a estas alturas, pero no te preocupes, la idea es que confirmes con tus coaches cualquier duda que tengas para tener mayor contexto. 

> Una recomendación adicional es "buscar en google" la etiqueta para ver la documentación técnica de la misma. Al mismo tiempo, encontrarás una gran comunidad de personas que podrán complementar todo lo que veas a continuación.

Nos situaremos en la etiqueta `<body>`.

Empezaremos por la etiqueta de `<header>` o la cabecera, para construirla.

```html

<body>

    <header> <!-- INICIA LA CABECERA O HEADER -->
        <nav> <!-- ETIQUETA DE NAVEGACIÓN -->

            <div> <!-- LADO IZQUIERDO DEL HEADER CON LOGO Y NOMBRE -->
                <div> <!-- CONTENIDO DE IMAGEN -->
                    <a href="#"> <!-- LINK EXTERNO -->
                        <img src="./img/foto.png" alt="Foto de autor" /> <!-- IMAGEN -->
                    </a>
                </div>
                <div> <!-- CONTENIDO DE NOMBRE -->
                    <a href="#">
                        Mike Nieva 
                    </a>
                </div>
            </div>

            <div> <!-- LADO DERECHO PARA BOTÓN "ENVÍAME UN CORREO -->                
                <a href="mailto:m@mikenieva.com">
                    Envíame un correo
                </a>
            </div>
        </nav>
    </header>

</body>
```

Observa cada etiqueta, sálvalo y refresca la página en tu navegador, obtendrás algo como esto:

![](./assets/7.png)

Si te aparece, perfecto. Vamos bien.

Consideraciones que quiero mencionarte:

- Las etiquetas tienen un desglose como escalera, es decir, una etiqueta abre y cierra. Siempre. Existen dos formas de hacerlo.

**1. Etiqueta de apertura y cierre.**

```html
<div> ... </div>
```

**2. Etiqueta en línea o "inline"**

```html
<img ... />
```

**¿Cómo sabemos cuál es cada una?** No hay forma intuitiva de saberlo. La teoría nos dice que si no hay contenido interno, será en línea, de lo contrario, será de apertura y cierre.

En la práctica, lo harás de manera intuitiva mientras más trabajes con HTML y cuáles etiquetas son de una o de otra.

- Hay una etiqueta a destacar y es `<div>`. Esta etiqueta se utiliza de manera general, es decir, si sólo queremos contener un contenido y no hay una etiqueta semántica que la describa mejor (header, nav, etc), entonces puedes aplicar un `<div>`. **Se le conoce como capa o contenedor general.**

- Los atributos son las propiedades que pueden tener las etiquetas para dar mayor información de cómo ejecutarse. Observa que tenemos:
    - `img`.
        - `src.` Se refiere a la ruta de la imagen. Es decir, en qué lugar de tu proyecto se encuentra. El concepto que se está utilizando es una ruta relativa. Es decir, debes darle las instrucciones de cómo llegar a esta "foto" desde tu archivo actual. 
        
        El `./` se refiere a la ubicación del archivo actualy cada diagonal es un punto de acceso. 
        
        Veamos el ejemplo:

        `./img/foto.png`. "Desde mi archivo actual (index.html) voy a acceder a la carpeta "img" y luego encontrar el archivo "foto.png"  

        - `alt`. Es una propiedad que permite dar una descripción de la imagen. Esto está relacionado con un tema de accesabilidad. Si una persona tiene complicaciones para ver la imagen, saldrá en texto, la descripción de la misma. 
        
        Puedes encontrar más información en la documentación. [Click aquí.](https://www.w3.org/QA/Tips/altAttribute.html.es)

    - `a`.
        - `href. ` Es la referencia del enlace. Es decir, ¿a qué página (interna o externa) quieres enlazar cuando el usuario de click aquí?


Con el header terminado, avancemos al desarrollo de la etiqueta `<main>`

## ALCANCE 5 - Harás las etiquetas HTML de `<main>`

Excelente, con esto ya vamos comprendiendo mejor cómo crear un sitio web.

Vamos a la siguiente sección, el cual será la sección de artículos. Inmediatamente después del `</header>`, integra este código.

Ve observando los comentarios en las etiquetas:

```html
    <main> <!-- CONTENEDOR DE CONTENIDO PRINCIPAL -->
        <div> <!-- CONTENEDOR DE DESCRIPCIÓN DEL BLOG -->
            <h1> <!-- TÍTULO DEL BLOG-->
              Mi blog de viajes
            </h1>
            <p> <!-- DESCRIPCIÓN DEL BLOG -->
              Conoce todos mis viajes alrededor del mundo.
            </p>
        </div>

        <div> <!-- CONTENEDOR DE LOS ARTÍCULOS DEL BLOG -->
            <div> <!-- CONTENEDOR DE 1 ARTÍCULO -->
                <div> <!-- CONTENEDOR DE LA IMAGEN DEL ARTÍCULO -->
                    <a href="#"> <!-- CONTENEDOR DEL LINK AL ARTÍCULO. EL "HASH" SIGNIFICA QUE SE MANTENGA EN LA MISMA PÁGINA POR AHORA -->
                        <img src="./img/puebla.jpg" alt="">
                    </a>
                </div>
                <div> <!-- CONTENEDOR DE TODA LA INFORMACIÓN DEL ARTÍCULO -->
                    <div> <!-- CONTENEDOR DE LA DESCRIPCIÓN DEL ARTÍCULO -->
                        <span>México</span> <!-- ETIQUETA GENERAL DE INFORMACIÓN -->
                        <a href="#">
                            <p>
                            Conociendo Puebla
                            </p>
                        </a>
                        <p>
                            En este viaje, aprendí mucho sobre la gastronomía poblana.En este viaje, aprendí mucho sobre la gastronomía poblana.
                        </p>
                        
                    </div>
                    <div> <!-- CONTENEDOR DE LA FECHA DEL ARTÍCULO -->  
                        <time datetime="2022-03-28"> <!-- FECHA DEL ARTÍCULO -->  
                            Marzo 28, 2022
                        </time>
                    </div>
                </div>
            </div>
        </div>
    </main>
```

Entre las consideraciones:

- Observa que la imagen de Puebla la puedes observar en la etiqueta `<img>`, a través de una ruta relativa.
- Tenemos una etiqueta llamada `time`, la cual cuenta con atributo llamado `datetime`, el cual lo único que hace es establecer la fecha en el formato `yyyy-mm-dd`.

Si traspasaste todo correctamente, verás esto:

![](./assets/8.png)

Pasemos al siguiente alcance.

## ALCANCE 6 - OBTENDRÁS TRES ARTÍCULOS

Ahora, ya que tenemos un `"CONTENEDOR DE 1 ARTÍCULO"`, lo copiarás y pegarás dos veces más para crear los dos artículos restantes.

Vas a seleccionar el código que ya construimos "CONTENEDOR DE UN ARTÍCULO" y lo triplicarás, quedando de esta forma. Recuerda que debe mantenerse dentro del "CONTENEDOR DE LOS ARTÍCULOS DEL BLOG".


```html
      <div> <!-- CONTENEDOR DE LOS ARTÍCULOS DEL BLOG -->
            <div> <!-- CONTENEDOR DE 1 ARTÍCULO -->
                <div>
                    <a href="#">
                        <img src="./img/puebla.jpg" alt="">
                    </a>
                </div>
                <div>
                    <div> 
                        <span>México</span>
                        <a href="#">
                            <p>
                            Conociendo Puebla
                            </p>
                        </a>
                        <p>
                            En este viaje, aprendí mucho sobre la gastronomía poblana.En este viaje, aprendí mucho sobre la gastronomía poblana.
                        </p>
                        
                    </div>
                    <div>
                        <time datetime="2022-03-28">
                            Marzo 28, 2022
                        </time>
                    </div>
                </div>
            </div>

            <!-- EMPEZAMOS A DUPLICAR -->
            <div> <!-- CONTENEDOR DE 1 ARTÍCULO -->
                <div>
                    <a href="#">
                        <img src="./img/puebla.jpg" alt="">
                    </a>
                </div>
                <div>
                    <div> 
                        <span>México</span>
                        <a href="#">
                            <p>
                            Conociendo Puebla
                            </p>
                        </a>
                        <p>
                            En este viaje, aprendí mucho sobre la gastronomía poblana.En este viaje, aprendí mucho sobre la gastronomía poblana.
                        </p>
                        
                    </div>
                    <div>
                        <time datetime="2022-03-28">
                            Marzo 28, 2022
                        </time>
                    </div>
                </div>
            </div>

            <div> <!-- CONTENEDOR DE 1 ARTÍCULO -->
                <div>
                    <a href="#">
                        <img src="./img/puebla.jpg" alt="">
                    </a>
                </div>
                <div>
                    <div> 
                        <span>México</span>
                        <a href="#">
                            <p>
                            Conociendo Puebla
                            </p>
                        </a>
                        <p>
                            En este viaje, aprendí mucho sobre la gastronomía poblana.En este viaje, aprendí mucho sobre la gastronomía poblana.
                        </p>
                        
                    </div>
                    <div>
                        <time datetime="2022-03-28">
                            Marzo 28, 2022
                        </time>
                    </div>
                </div>
            </div>
            
        </div>
```

Con esto, obtendrás 3 "volcanes", que se encuentran dentro del contenedor.

Está bien que tengan los mismos contenidos repetidos, ya en los alcances siguientes se les cambiarán los datos.

Por ahora, si todo correcto, avancemos a la parte de estilos, que nos permitirá mejorar el proyecto desde la interfaz.

## ALCANCE 7 - Insertarás estilos dentro las etiquetas

Bien. Repasemos un poco.

**HTML.** Se refiere al esqueleto del proyecto. Las etiquetas y estructura.

**CSS.** Se refiere a la interfaz. El diseño visual que se le aplica al HTML.

Para esto, nosotros ya creamos un archivo llamado `estilos.css`. En este archivo, se colocarán todos los estilos visuales de nuestro HTML.

No lo construiremos desde cero. [Copiarás el código de aquí](https://github.com/UDDBootcamp/PPV-Landing-Blog/blob/main/estilos.css) y lo pegarás en tu archivo de `estilos.css`. 

**¿Por qué hacemos esto y no desde cero?**

CSS, a diferencia de HTML, se requiere de conocer las propiedades a fondo, ya que una propiedad o estilo mal colocado puede romper todo el contenido visual.

Sin embargo, esto no significa que no haremos nada. Lo que nos enfocaremos es cómo colocar los estilos en nuestras etiquetas HTML y denotar algunas propiedades relevantes.

Bien, una vez integrado el código `CSS`, es momento de añadir las clases a nuestro código HTML.

Recordemos que una clase dentro de HTML es el nombre de un estilo, el cual contiene múltiples propiedades que alteran a esa etiqueta.

Por ejemplo:

```html
<p class="saludo">hola mundo</p>
```

```css
.saludo {
    color: blue;
}

```

Observa que la clase ("class") se llama **saludo.** Esto significa que en nuestro CSS hay una clase, que su sintaxis es empezar con un punto (`.`) que se llama **saludo**.

Dentro de la clase, vemos una propiedad y un valor. 

- **color** es la propiedad y se refiere al color que tendrá este párrafo.
- **blue** es el valor que tiene esta propiedad.

Adicionalmente, también notarás que en muchos archivos CSS encontrarás este formato:

```css
p {
    color: blue
}
```

En este caso, lo que estamos proponiendo es que todos los párrafos cambien a color azul. Puedes, si quieres, no utilizar clases y afectar a una etiqueta de manera directa.

Y listo. Recuerda, si vas teniendo dudas e inquietudes, acércate a tus coaches.

> No olvides que en el ALCANCE TRES hicimos la conexión del archivo CSS con la etiqueta <link>. Si no haces esta conexión, tu CSS no podrá hablar con tu HTML y los estilos no se mostrarán.

Vamos a ir agregando cada clase en cada etiqueta HTML. Observa el código a continuación y velo añadiendo poco a poco, línea por línea. 

**Aunque podrías copiarlo y pegarlo, no lo hagas, ve poco a poco para que puedas ir comprendiendo cómo se integra.**

```html
<body>
      <header>
        <nav>
          <div class="left-nav">
            <div class="image-content">
              <a href="#">
                <img class="profile-pic" src="./img/foto.png" alt="Foto de perfil">
              </a>
            </div>
            <div class="name-content">
                <a href="#">
                    Mike Nieva
                </a>
            </div>
          </div>
          <div class="contact-content">
            <a href="mailto:m@mikenieva.com">
              Envíame un correo
            </a>
          </div>
        </nav>    
      </header>
    
    <main>
          <div class="blog-description">
            <h1>
              Mi blog de viajes
            </h1>
            <p>
              Conoce todos mis viajes alrededor del mundo.
            </p>
          </div>

          <div class="articles-area">


            <div class="article-area">
              <div class="image-article-area">
                  <a href="#">
                        <img src="./img/puebla.jpg" alt="">
                    </a>
              </div>
              <div class="info-article">
                <div>
                  <span>
                      México
                  </span>
                  <a href="#">
                    <p class="title-info-article">
                      Conociendo Puebla
                    </p>
                  </a>
                  <p>
                      En este viaje, aprendí mucho sobre la gastronomía poblana.En este viaje, aprendí mucho sobre la gastronomía poblana.
                  </p>
                  
                </div>
                <div class="date-area">  
                      <time datetime="2022-03-28">
                        Marzo 28, 2022
                      </time>
                </div>
              </div>
            </div>

            <div class="article-area">
              <div class="image-article-area">
                  <a href="#">
                        <img src="./img/puebla.jpg" alt="">
                    </a>
              </div>
              <div class="info-article">
                <div>
                  <span>
                      México
                  </span>
                  <a href="#">
                    <p class="title-info-article">
                      Conociendo Puebla
                    </p>
                  </a>
                  <p>
                      En este viaje, aprendí mucho sobre la gastronomía poblana.En este viaje, aprendí mucho sobre la gastronomía poblana.
                  </p>
                  
                </div>
                <div class="date-area">  
                      <time datetime="2022-03-28">
                        Marzo 28, 2022
                      </time>
                </div>
              </div>
            </div>

            <div class="article-area">
              <div class="image-article-area">
                  <a href="#">
                        <img src="./img/puebla.jpg" alt="">
                    </a>
              </div>
              <div class="info-article">
                <div>
                  <span>
                      México
                  </span>
                  <a href="#">
                    <p class="title-info-article">
                      Conociendo Puebla
                    </p>
                  </a>
                  <p>
                      En este viaje, aprendí mucho sobre la gastronomía poblana.En este viaje, aprendí mucho sobre la gastronomía poblana.
                  </p>
                </div>
                <div class="date-area">  
                      <time datetime="2022-03-28">
                        Marzo 28, 2022
                      </time>
                </div>
              </div>
            </div>
          </div>
      </main>
</body>

```

Consideraciones importantes que seguro ya notaste:

- Las etiquetas contienen un atributo llamado **class** y el valor es el que está anclado en tu archivo CSS.
- Conforme vas agregando los datos, tu sitio web empieza a cambiar en estilos.
- Todo el `body` puede ser manipulado con CSS.

Tu proyecto final debería quedarte de esta forma:

![](./assets/10.png)

Hasta que no tengas una imagen similar, no avances. Revisa correctamente la estructura. 

Es muy común que una etiqueta no la cierres correctamente, o el estilo lo hayas llamado distinto. Hazlo poco a poco y tan pronto llegues a esta imagen, avanza.

## ALCANCE 8 - Cambiarás el contenido por el que tú gustes, incluye Javascript

Genial. Ya tenemos un blog bastante sólido y ya hemos practicado muchísimos conceptos.

A partir de aquí, vamos a dejarte el ejercicio abierto. El objetivo es que empieces a personalizar.

- Usa otras imágenes.
  
- Utiliza otros textos.

- Agrega más artículos, si quieres.

- Opcionalmente puedes agregar nuevas páginas. La estructura sería igual que esta y puedes aventurarte a jugar con los estilos.

- Y claro deberás agregar algunos elementos utilizando Javascript.

Una vez que te sientas en comodidad con tu resultado, siente mucho orgullo por lo que acabas de construir. 

![](./assets/11.gif)

Hasta aquí, sería nuestra actividad guiada. Tus siguientes pasos es que presentes este proyecto a través de la plataforma LOOM.

Esta plataforma te permitirá grabar tu pantalla y voz al simultáneo. 

Tienes 3 minutos para contarnos:

- ¿Cómo se ve tu proyecto terminado?
- ¿Qué aprendiste en este taller?
- Tus siguientes pasos.

Si tienes inquietudes, acércate al Staff y coaches.

Excelente trabajo.


